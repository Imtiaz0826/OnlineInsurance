export class User {

    id!: number;
    userName!: string;
    password!: string;
    firstName!: string;
    lastName!: string;
    gender!: string;
    dob!: string;
    email!: string;
}

